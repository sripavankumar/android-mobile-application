package com.example.quizgame.util;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class DatabaseHelper extends SQLiteOpenHelper {

    public static final int VERSION = 1;
    public static final String NAME = "quiz.db";

    public static final String TABLE_HIGH_SCORE = "highscore";

    public static final String GAME_NAME = "game_name";
    public static final String BEST_SCORE = "best_score";
    public static final String ATTEMPTS = "attempts";

    public DatabaseHelper(Context context) {
        super(context,NAME,null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {


        String CREATE_TABLE_HIGH_SCORE = "CREATE TABLE "+TABLE_HIGH_SCORE+"("+
                GAME_NAME+ " TEXT,"+
                BEST_SCORE+" INTEGER,"+
                ATTEMPTS+" INTEGER"+
                ")";
        db.execSQL(CREATE_TABLE_HIGH_SCORE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_HIGH_SCORE);
        onCreate(db);
    }


    public void setHighScore(String game_name,int score,int attempt){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(GAME_NAME,game_name);
        contentValues.put(BEST_SCORE,score);
        contentValues.put(ATTEMPTS,attempt);
        sqLiteDatabase.insert(TABLE_HIGH_SCORE,null,contentValues);
    }

    public void updateHighScore(String game_name,int score,int attempt){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(GAME_NAME,game_name);
        contentValues.put(BEST_SCORE,score);
        contentValues.put(ATTEMPTS,attempt);
        sqLiteDatabase.insert(TABLE_HIGH_SCORE,null,contentValues);
    }


    public void updateHightScore(String game_name,int score,int attempt){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(BEST_SCORE,score);
        contentValues.put(ATTEMPTS,attempt);
        sqLiteDatabase.update(TABLE_HIGH_SCORE,contentValues,GAME_NAME+" =?",new String[]{String.valueOf(game_name)});
    }


    public int getAttempts(String game_name){
        String countQuery = "SELECT  * FROM " + TABLE_HIGH_SCORE +" WHERE "+GAME_NAME+ " =?";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, new String[]{game_name});
        int attempts = 0;
        if(cursor!=null && cursor.getCount()>0){
            cursor.moveToFirst();
            attempts = cursor.getInt(cursor.getColumnIndex(ATTEMPTS));
            cursor.close();
        }

        return attempts;
    }

    public int getHighScore(String game_name){
        String countQuery = "SELECT  * FROM " + TABLE_HIGH_SCORE+" WHERE "+GAME_NAME+ " =?";;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, new String[]{game_name});
        int highScore = 0;
        if(cursor!=null && cursor.getCount()>0){
            cursor.moveToFirst();
            highScore = cursor.getInt(cursor.getColumnIndex(BEST_SCORE));
            cursor.close();
        }

        return highScore;
    }

}
