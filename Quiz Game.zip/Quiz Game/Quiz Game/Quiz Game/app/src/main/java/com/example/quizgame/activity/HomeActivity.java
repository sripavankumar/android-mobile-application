package com.example.quizgame.activity;

import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import com.example.quizgame.R;
import com.example.quizgame.util.Utility;

import butterknife.BindView;
import butterknife.ButterKnife;

public class HomeActivity extends AppCompatActivity {

    @BindView(R.id.tvMaths)
    TextView tvMaths;
    @BindView(R.id.tvQuiz)
    TextView tvQuiz;
    @BindView(R.id.tvSettings)
    TextView tvSettings;
    @BindView(R.id.tvHighScore)
    TextView tvHighScore;
    @BindView(R.id.tvUpDown)
    TextView tvUpDown;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_activity);
        ButterKnife.bind(this);


        tvMaths.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, MathsProblem.class);
                startActivity(intent);
            }
        });

        tvQuiz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, QuizActivity.class);
                startActivity(intent);
            }
        });

        tvUpDown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, SensorGame.class);
                startActivity(intent);
            }
        });

        tvSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this,SettingActivity.class);
                startActivity(intent);
            }
        });

        tvHighScore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this,HighScore.class);
                startActivity(intent);

            }
        });


    }

    @Override
    public void onBackPressed() {
        Utility.showExitDialogBox(HomeActivity.this);
    }
}
