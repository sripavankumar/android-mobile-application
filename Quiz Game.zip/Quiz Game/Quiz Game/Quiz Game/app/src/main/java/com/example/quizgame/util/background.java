package com.example.quizgame.util;

public class background {
   public static void run(Runnable runnable) {
        Thread thread = new Thread(runnable);
        thread.start();
    }
}
