package com.example.quizgame;


import android.app.Application;
import android.content.Context;

import com.facebook.stetho.Stetho;


public class ApplicationClass extends Application {
    public static Context appContext;
    @Override
    public void onCreate() {
        super.onCreate();
        appContext = this;
        Stetho.initializeWithDefaults(this);
    }
}
