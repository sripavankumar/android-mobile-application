package com.example.quizgame.activity;

import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.quizgame.R;
import com.example.quizgame.util.Constants;
import com.example.quizgame.util.DatabaseHelper;
import com.example.quizgame.util.PreferenceHelper;
import com.example.quizgame.util.Utility;

import butterknife.BindView;
import butterknife.ButterKnife;

public class QuizActivity extends AppCompatActivity {

    @BindView(R.id.tvQuestion)
    TextView tvQuestion;
    @BindView(R.id.etAnswer)
    TextView etAnswer;
    @BindView(R.id.tvBoard)
    TextView tvBoard;
    @BindView(R.id.buttomSubmit)
    Button buttonSubmit;
    @BindView(R.id.ivBack)
    ImageView ivBack;

    int counter = 0;
    int rightAnswer;

    String[] array;

    String[] arrayEasy = new String[]{"How many legs does a spider have?(in digit):8",
            "What’s the name of a place you go to see lots of animals?:Zoo",
            "If you freeze water, what do you get?:Ice",
            "How many pairs of wings do bees have?(in digit):2",
            "What do bees make?:Honey",
            "What color are Smurfs?:Blue"
    };

    String[] arrayHard = new String[]{
            "In arithmetic, what is the value of 4! i.e. four factorial?(in digit): 24",
            "How many Apollo missions landed men on the moon?(in digit):6",
            "Who was Henry VIII's wife at the time of his death?:Catherine Parr",
            "Played by rapper Method Man, Cheese Wagstaff was the last on-screen character to die in which drama series?:Wire",
            "Suharto held the office of president in which large Asian nation?:Indonesia",
            "Derived from a profession/trade, what is the English equivalent of the German surname Fassbinder/Fassbender?:Cooper"
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        boolean easyMode = PreferenceHelper.getInstance().getBooleanPreference(Constants.PREF_MODE);
        if (easyMode) {
            array = arrayEasy;
        } else {
            array = arrayHard;
        }
        setContentView(R.layout.quiz_activity);
        ButterKnife.bind(this);


        getQuestion();

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (etAnswer.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Enter answer!", Toast.LENGTH_LONG).show();
                } else {
                    String studentAnswer = etAnswer.getText().toString();
                    if (studentAnswer.equalsIgnoreCase(array[counter].split(":")[1])) {
                        rightAnswer++;
                        Toast.makeText(getApplicationContext(), "Correct.", Toast.LENGTH_SHORT).show();
                    } else {
                        Log.i("Answer", "Wrong");
                        Utility.setVibrate(getApplicationContext());
                        Toast.makeText(getApplicationContext(), "Answer is " + array[counter].split(":")[1], Toast.LENGTH_LONG).show();
                    }
                    if (counter < array.length - 1) {
                        etAnswer.setText("");
                        counter++;
                        getQuestion();
                        tvBoard.setText(counter + 1 + "/5");
                    } else {
                        //gamecomplete
                        //show Alert
                        Utility.showResultDialogBox(QuizActivity.this, getApplicationContext(), rightAnswer, array.length);
                        DatabaseHelper databaseHelper = new DatabaseHelper(getApplicationContext());
                        int attempts = databaseHelper.getAttempts("QUIZ");
                        int highscore = databaseHelper.getHighScore("QUIZ");
                        if (rightAnswer > highscore) {
                            databaseHelper.updateHightScore("QUIZ", rightAnswer, attempts + 1);
                        } else {
                            databaseHelper.updateHightScore("QUIZ", highscore, attempts + 1);
                        }
                    }
                }
            }
        });

        tvBoard.setText(counter + 1 + "/"+array.length);

        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

    }

    private void getQuestion() {
        tvQuestion.setText(array[counter].split(":")[0]);
    }
}
