package com.example.quizgame.activity;


import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioGroup;

import com.example.quizgame.R;
import com.example.quizgame.util.Constants;
import com.example.quizgame.util.PreferenceHelper;


import butterknife.BindView;
import butterknife.ButterKnife;


public class SettingActivity extends AppCompatActivity {
    @BindView(R.id.ivBack)
    ImageView ivBack;
    @BindView(R.id.radioGroupMode)
    RadioGroup radioGroupMode;
    @BindView(R.id.radioGroupVibrate)
    RadioGroup radioGroupVibrate;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setting_activity);
        ButterKnife.bind(this);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        boolean easyMode = PreferenceHelper.getInstance().getBooleanPreference(Constants.PREF_MODE);
        boolean vibrate = PreferenceHelper.getInstance().getBooleanPreference(Constants.PREF_VIBRATE);

        if(easyMode){
            radioGroupMode.check(R.id.rbEasy);
        }else{
            radioGroupMode.check(R.id.rbHard);
        }

        if(vibrate){
            radioGroupVibrate.check(R.id.rbYes);
        }else{
            radioGroupVibrate.check(R.id.rbNo);
        }


        radioGroupMode.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.rbEasy) {
                    PreferenceHelper.getInstance().setBooleanPreference(Constants.PREF_MODE,true);
                } else {
                    PreferenceHelper.getInstance().setBooleanPreference(Constants.PREF_MODE,false);
                }
            }
        });

        radioGroupVibrate.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.rbYes) {
                    PreferenceHelper.getInstance().setBooleanPreference(Constants.PREF_VIBRATE,true);
                } else {
                    PreferenceHelper.getInstance().setBooleanPreference(Constants.PREF_VIBRATE,false);
                }
            }
        });

    }
}
