package com.example.quizgame.activity;


import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.TextView;

import com.example.quizgame.R;
import com.example.quizgame.util.DatabaseHelper;

import java.util.Timer;
import java.util.TimerTask;


public class SplashScreen extends AppCompatActivity {
    private DatabaseHelper databaseHelper;
    private TextView tvName;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_activity);
        tvName = (TextView)findViewById(R.id.tvName);
        databaseHelper = new DatabaseHelper(this);
        if(databaseHelper.getHighScore("MATHS")==0 && databaseHelper.getHighScore("QUIZ")==0){
            databaseHelper.setHighScore("MATHS",0,0);
            databaseHelper.setHighScore("QUIZ",0,0);
        }
        Timer timer = new Timer();
        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                Intent intent = new Intent(SplashScreen.this, HomeActivity.class);
                startActivity(intent);
                finish();
            }
        };
        timer.schedule(timerTask,2000);

    }

}
