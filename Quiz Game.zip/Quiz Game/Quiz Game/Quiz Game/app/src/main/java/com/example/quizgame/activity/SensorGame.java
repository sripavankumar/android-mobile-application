package com.example.quizgame.activity;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.quizgame.R;

import butterknife.BindView;
import butterknife.ButterKnife;

public class SensorGame extends AppCompatActivity implements SensorEventListener {

    @BindView(R.id.ivBack)
    ImageView ivBack;
    @BindView(R.id.ivImage)
    ImageView ivImage;


    private SensorManager mSensorManager;
    private Sensor mGravitySensor;
    private boolean turtleUp;
    private boolean mFacingDown;

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // nothing
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        final float factor = 0.7F;

        if (event.sensor == mGravitySensor) {
            boolean nowDown = event.values[2] < -SensorManager.GRAVITY_EARTH * factor;
            Log.d("NOW DOWN", String.valueOf(nowDown));
            if (nowDown != mFacingDown) {
                if (nowDown) {
                   //changeImage();
                } else {
                    changeImage();
                }
                mFacingDown = nowDown;
            }
        }
    }

    private void changeImage(){
        if(turtleUp){
            turtleUp = false;
            ivImage.setImageResource(R.drawable.turtle_down);
        }else{
            turtleUp = true;
            ivImage.setImageResource(R.drawable.turtle_up);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.updown_activity);
        ButterKnife.bind(this);

        turtleUp = true;

        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        mGravitySensor = mSensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY);

        if (mGravitySensor == null) {
            Toast.makeText(getApplicationContext(),"No sensor detected",Toast.LENGTH_LONG).show();
        }

        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mGravitySensor != null) {
            mSensorManager.registerListener(this, mGravitySensor, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        mSensorManager.unregisterListener(this);
    }
}
