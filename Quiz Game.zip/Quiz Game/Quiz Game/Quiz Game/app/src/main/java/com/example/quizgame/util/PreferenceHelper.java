package com.example.quizgame.util;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.quizgame.ApplicationClass;



public class PreferenceHelper {

    private static Context context;
    public static PreferenceHelper preferenceHelper;

    public static PreferenceHelper getInstance(){
        if(preferenceHelper==null){
            preferenceHelper = new PreferenceHelper();
        }
        return preferenceHelper;
    }

    public PreferenceHelper() {
        context = ApplicationClass.appContext.getApplicationContext();
    }


    public void setStringPreference(String key,String value){
        getSharedPreferences().edit().putString(key,value).commit();
    }

    public void setBooleanPreference(String key,boolean value){
        getSharedPreferences().edit().putBoolean(key,value).commit();
    }

    public SharedPreferences getSharedPreferences(){
        return context.getSharedPreferences("MyPref",Context.MODE_PRIVATE);
    }

    public void setIntPreference(String key,int value){
        getSharedPreferences().edit().putInt(key,value).commit();
    }

    public String getStringPreference(String key){
        return getSharedPreferences().getString(key,null);
    }

    public Boolean getBooleanPreference(String key){
        return getSharedPreferences().getBoolean(key,true);
    }

    public int getIntPreference(String key){
        return getSharedPreferences().getInt(key,50);
    }

}
