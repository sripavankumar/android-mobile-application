package com.example.quizgame.activity;

import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.quizgame.R;
import com.example.quizgame.util.DatabaseHelper;

import butterknife.BindView;
import butterknife.ButterKnife;

public class HighScore  extends AppCompatActivity {

    @BindView(R.id.tvMathsHighScore)
    TextView tvMathsHighScore;
    @BindView(R.id.tvMathsAttempt)
    TextView tvMathsAttempt;
    @BindView(R.id.tvQuizHighScore)
    TextView tvQuizHighScore;
    @BindView(R.id.tvQuizAttempt)
    TextView tvQuizAttempt;
    @BindView(R.id.ivBack)
    ImageView ivBack;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.high_score_activity);
        ButterKnife.bind(this);

        DatabaseHelper databaseHelper = new DatabaseHelper(getApplicationContext());

        tvMathsAttempt.setText(String.valueOf(databaseHelper.getAttempts("MATHS")));
        tvMathsHighScore.setText(String.valueOf(databaseHelper.getHighScore("MATHS")));

        tvQuizAttempt.setText(String.valueOf(databaseHelper.getAttempts("QUIZ")));
        tvQuizHighScore.setText(String.valueOf(databaseHelper.getHighScore("QUIZ")));

        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

    }


}
