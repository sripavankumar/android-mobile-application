package com.example.quizgame.activity;

import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.quizgame.R;
import com.example.quizgame.util.DatabaseHelper;
import com.example.quizgame.util.Utility;

import java.util.Random;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MathsProblem extends AppCompatActivity {
    int firstNumber;
    int secondNumber;
    @BindView(R.id.tvQuestion)
    TextView tvQuestion;
    @BindView(R.id.etAnswer)
    TextView etAnswer;
    @BindView(R.id.tvBoard)
    TextView tvBoard;
    @BindView(R.id.buttomSubmit)
    Button buttonSubmit;
    @BindView(R.id.ivBack)
    ImageView ivBack;

    private int resultNumber;

    int counter=1;
    int rightAnswer;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.maths_activity);
        ButterKnife.bind(this);

        getQuestion();

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(etAnswer.getText().toString().isEmpty()){
                    Toast.makeText(getApplicationContext(),"Enter answer!",Toast.LENGTH_LONG).show();
                }else{
                    int studentAnswer = Integer.parseInt(etAnswer.getText().toString());
                    if(studentAnswer == resultNumber){
                       rightAnswer ++;
                        Toast.makeText(getApplicationContext(),"Right Answer.",Toast.LENGTH_SHORT).show();
                    }else{
                        Log.i("Answer","Wrong");
                        Utility.setVibrate(getApplicationContext());
                        Toast.makeText(getApplicationContext(),"Oops Wrong!",Toast.LENGTH_SHORT).show();
                    }
                    if(counter<20){
                        etAnswer.setText("");
                        getQuestion();
                        counter ++;
                        tvBoard.setText(counter+"/20");
                    }else{
                        //gamecomplete
                        //show Alert
                        Utility.showResultDialogBox(MathsProblem.this,getApplicationContext(),rightAnswer,20);
                        DatabaseHelper databaseHelper = new DatabaseHelper(getApplicationContext());
                        int attempts = databaseHelper.getAttempts("MATHS");
                        int highscore = databaseHelper.getHighScore("MATHS");
                        if(rightAnswer>highscore){
                            databaseHelper.updateHightScore("MATHS",rightAnswer,attempts+1);
                        }else{
                            databaseHelper.updateHightScore("MATHS",highscore,attempts+1);
                        }
                    }
                }
            }
        });

        tvBoard.setText(counter+"/20");

        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

    }

    private void getQuestion() {
        Random random = new Random();
        int bound = 0;
        Boolean easyMode = Utility.getMode(getApplicationContext());
        if(easyMode){
            bound = 100;
        }else{
            bound = 1000;
        }
        firstNumber = Math.abs(random.nextInt(bound));
        secondNumber = random.nextInt(firstNumber);
        String operation="";
        if(secondNumber%2 == 0){
            resultNumber = firstNumber+secondNumber;
            operation = "  +  ";
        }else{
            operation = "  -  ";
            resultNumber = firstNumber-secondNumber;
        }
        tvQuestion.setText("  "+firstNumber+operation+secondNumber+"  ");
    }

}
