package com.example.quizgame.util;

public class Constants {
    public static final String PREF_VIBRATE = "pref_vibrate";
    public static final String PREF_MODE = "pref_mode";
}
