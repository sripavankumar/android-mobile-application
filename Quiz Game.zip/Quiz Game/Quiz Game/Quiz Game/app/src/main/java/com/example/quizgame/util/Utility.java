package com.example.quizgame.util;



import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.quizgame.activity.HomeActivity;
import com.example.quizgame.R;

import java.util.Locale;

import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;


public class Utility {
    private static Twitter twitter = TwitterFactory.getSingleton();

    public static void showExitDialogBox(final AppCompatActivity activity){
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(activity);
        LayoutInflater inflater = activity.getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.exit_dialog_box, null);
        dialogBuilder.setView(dialogView);

        final AlertDialog alertDialog = dialogBuilder.create();
        alertDialog.setCancelable(false);

        TextView tvYes = (TextView)dialogView.findViewById(R.id.tvYes);
        TextView tvNo = (TextView)dialogView.findViewById(R.id.tvNo);


        tvYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.finish();
            }
        });

        tvNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    alertDialog.dismiss();
            }
        });
        alertDialog.show();
    }

    public static void showResultDialogBox(final AppCompatActivity activity, final Context context, final int result, int totalQuestion){
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(activity);
        LayoutInflater inflater = activity.getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.result_dialog_box, null);
        dialogBuilder.setView(dialogView);

        final AlertDialog alertDialog = dialogBuilder.create();
        alertDialog.setCancelable(false);

        TextView tvHome = (TextView)dialogView.findViewById(R.id.tvHome);
        TextView tvPlayAgain = (TextView)dialogView.findViewById(R.id.tvPlayAgain);
        TextView tvResult = (TextView)dialogView.findViewById(R.id.tvResult);
        Button tvtwitter = (Button)dialogView.findViewById(R.id.twitter);

        tvResult.setText(result+" correct answer and "+(totalQuestion-result)+" wrong answer");

        tvHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity, HomeActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                context.startActivity(intent);
            }
        });
        tvPlayAgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity, activity.getClass());
                /*intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);*/
                context.startActivity(intent);
            }
        });


        tvtwitter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                background.run(() -> {
                    if (isAuthorised()) {
                        try {
                            twitter.updateStatus("My score is " + result);
                            Log.i("Twitter", String.format(Locale.getDefault(), "Status updated: %s", "My score is " + result));
                        } catch (TwitterException e) {
                            Log.i("Twitter", String.format(Locale.getDefault(),
                                    "Something bad happened while tweeting: %s", e.toString()));
                        }
                    }
                });

            }
        });

        alertDialog.show();
    }



    public static void setVibrate(Context context){
        Boolean vibrate = PreferenceHelper.getInstance().getBooleanPreference(Constants.PREF_VIBRATE);
        Vibrator v = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        if(vibrate){
            // Vibrate for 500 milliseconds
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                v.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE));
            }else{
                //deprecated in API 26
                v.vibrate(500);
            }
        }
    }


    public static boolean getMode(Context context){
        Boolean easyMode = PreferenceHelper.getInstance().getBooleanPreference(Constants.PREF_MODE);
        return easyMode;
    }

    private static boolean isAuthorised() {
        try {
            twitter.verifyCredentials();
            Log.i("Twitter", "User is verified");
            return true;
        } catch (Exception e) {
            Log.i("Twitter", "User is not verified");
            return false;
        }
    }
}
